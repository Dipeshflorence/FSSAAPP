# Florence Security Service Agency – native app shell (Capacitor)

The prototype (`www/index.html`) wrapped for Android and iOS.
App ID: `in.florencesecurity.app`. Change it in `capacitor.config.json`
BEFORE the first store submission; it cannot be changed afterwards.

## One-time setup
Needs Node.js (current LTS). Android: Android Studio. iOS: a Mac with Xcode.

    npm install @capacitor/core @capacitor/android @capacitor/ios
    npm install -D @capacitor/cli @capacitor/assets
    npx cap add android
    npx cap add ios          # Mac only
    npm run assets           # makes icons + splash from /assets
    npx cap sync

## Build
Android:  `npm run android`  -> Android Studio -> Build > Build APK, or
          Build > Generate Signed Bundle (.aab) for Google Play.
iOS:      `npm run ios`      -> Xcode -> choose a team -> run, or Product > Archive.

After editing `www/index.html`, run `npx cap sync` again.

## Store accounts
Google Play developer account (one-time fee). Apple Developer Program (yearly fee).

## Known limits of this build
- It is still the prototype: data is stored on the device only, admin sign-in accepts
  any entry, and there is no server. Backend phase replaces this.
- Print / Download PDF show a message in the native app (needs server-made PDFs).
- SMS / WhatsApp / Email buttons open the device apps; automatic sending needs the backend.
- Photo upload uses the system file picker. For direct camera use, add @capacitor/camera.
- Fonts load from Google Fonts when online and fall back to system fonts offline.
- Emergency GPS, push notifications and background alerts need native plugins
  (@capacitor/geolocation, @capacitor/push-notifications) plus the backend.

## Get an APK without installing anything (GitHub Actions)
1. Create a free GitHub account and a new private repository.
2. Upload ALL files from this folder, including the hidden `.github` folder, to the `main` branch.
3. Open the repository's Actions tab, choose "Build Android APK", press Run workflow.
4. After a few minutes, open the finished run and download `florence-security-apk` from Artifacts.
5. Unzip it and install `app-debug.apk` on an Android phone (allow "install unknown apps").
This is a debug APK for testing. Google Play needs a signed release bundle (.aab).
